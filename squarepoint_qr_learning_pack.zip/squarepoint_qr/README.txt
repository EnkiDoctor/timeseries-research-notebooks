Squarepoint QR onsite 准备：pandas → 数据研究 → 策略与回测
制作日期：2026-10-05（Asia/Hong_Kong）

先从哪里开始
1. 01_pandas_refresher.ipynb：中文讲解、逐格示例、5组练习和可折叠答案。
   适合忘了 pandas、但仍记得基础 Python 的你；建议 3–5 小时。
2. 02_onsite_practice.ipynb：独立的10题模拟练习。建议先不限时完成，再做150分钟模拟。
   TODO 故意保留，Run All 不报错不等于题目完成。答案在下一本。
3. 03_research_solution.ipynb：完整研究链条，已保存执行结果与图表。
   数据清洗 → EDA/相关性 → 信号与标签 → IC → 组合 → 有成本回测 → 样本外 → Ridge扩展。

同名 .html 文件是只读阅读版：浏览器打开即可看文字、代码、已运行输出；无需装 Python。
编辑与练习请用 .ipynb。01 的折叠答案可复制到练习格。02 故意没有已解答内容。

数据
data/industry_returns.csv：真实的30行业市值加权日收益，2010-01-04至2025-12-31。
4,024个交易日 × 30行业 = 120,720行长表记录。return_pct 要除以100才是小数收益。
data/dirty_industry_returns.csv：人为污染的独立清洗题，120,780行；清洗后应剩120,720行、60个缺失收益。
data/industries.csv：官方行业名称映射。
data/DATA_README.txt、source_metadata.json：来源、单位、哈希、版本与局限。
data/source/：下载快照，用来核对来源，不是 notebook 运行的必要条件。

运行方法（建议 Python 3.12）
把整个 squarepoint_qr 文件夹解压，保留 notebook 与 data/ 的相对位置。
在终端切换到这个文件夹，再运行：

    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install -r requirements.txt
    python -m jupyterlab

Windows 激活命令改成 .venv\Scripts\activate（PowerShell 可用 Activate.ps1）。
也可用 VS Code 的 Jupyter 扩展打开 .ipynb，选择安装好依赖的 Python kernel。
若报“找不到 data”，检查 notebook 的工作目录是否为本文件夹；不要只下载一个 notebook。
依赖安装需要联网；安装完成后，全部例子和金融数据分析均可离线运行，无需 API key。
通过 Kernel → Restart Kernel and Run All Cells 检查可复现性，避免依赖旧变量。

学习安排
第一轮：01 第1–11节，熟悉表结构、筛选、清洗、分组和合并。
第二轮：01 第12–20节，掌握 groupby + shift/rolling 与时间对齐，完成5组练习。
第三轮：做02的Q1–Q7；卡住时只看03对应段，随后关掉答案重写。
第四轮：完成回测与样本外Q8–Q10，并练习5分钟口头汇报。
时间不足时优先：loc、groupby agg/transform、merge validate、pivot、shift/rolling、corrwith。
能解释数据粒度、输出形状、单位与可用时点，比记住全部 API 更重要。

研究约定
train=2010–2018；validation=2019–2021；test=2022–2025。
收盘t产生信号，t+1收盘交易，t+2首次获得该日收益。主例每单位双边交易金额收5bps。
从现金开始，考虑权重漂移、首次建仓及最终平仓。参数仅在固定validation候选中选择。
反复运行已冻结代码可以；看test后再改策略，就不能继续称其为未触碰的样本外测试。
数据为研究行业组合，不是可直接成交的ETF。缺少逐股票成分/执行/融券数据，并有历史修订。
示例是研究方法教学，不宣称发现可直接部署的策略，也不是Squarepoint官方真题或已确认面试流程。

验证
01与03代码从干净kernel完整执行；02仅初始化与函数骨架执行，TODO须由你完成。
已检查数据与源文件一致、无未来特征污染、无费回测向量化对齐、手算交易费、权重漂移和初始回撤。
依赖版本见 requirements.txt 与 verification.json。图表和输出保存在 notebook 内。

一手资料
https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_30_ind_port.html
https://pandas.pydata.org/docs/user_guide/10min.html
更多API与统计方法链接已在notebook内标注。
