Pandas / Quantitative Research 练习数据说明

来源：Kenneth R. French Data Library，30 Industry Portfolios [Daily]。
官方下载：https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/30_Industry_Portfolios_daily_CSV.zip
组合定义：https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_30_ind_port.html
行业全名：https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/Siccodes30.zip
数据总览与历史修订说明：https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
下载日期：2026-10-05（Asia/Hong_Kong）。源文件 CRSP 版本：202608。

本数据包选取 Average Value Weighted Returns -- Daily（市值加权日收益率）表。
筛选范围：2010-01-01 至 2025-12-31（两端包含）；实际日期 2010-01-04 至 2025-12-31。
共有 4,024 个源数据交易日、30 个行业、120,720 行长表记录。
date 是源数据的美国市场交易日期，没有时分秒或时区。周末、休市日没有记录；
不要用普通工作日日历补齐并把空值当作零收益。252 仅是分析时常用的年化近似，
不意味着每个自然年有恰好 252 行。

文件和字段
1. industry_returns.csv：clean 数据。
   date：YYYY-MM-DD；industry：官方行业简写；return_pct：百分数单位的简单日收益率。
   例：1.25 表示 +1.25%，用于复利或回测前必须除以 100 得到 0.0125。
   这是组合收益率，不是相对无风险利率的超额收益率，也不是价格、对数收益率。
2. industries.csv：industry 和 industry_name，用于练习 many-to-one merge。
   行业名称直接解析自官方 Siccodes30.txt，不自行推断名称。
3. dirty_industry_returns.csv：人为加入问题的独立清洗练习，见下文。
4. source_metadata.json：来源、哈希、筛选逻辑、维度和缺失值记录。

原始数据的缺失编码是 -99.99 或 -999。本包将这些编码转换为缺失值。
所选 2010–2025 区间共发现 0 个这种编码，clean 收益缺失数为 0。
未填充收益率、未缩尾、未补日、未合成价格/OHLC/成交量。
clean 的 date + industry 键唯一，排序为 date、industry 升序。

金融含义和使用边界
官方按六月末的 SIC 行业分类把 NYSE、AMEX、NASDAQ 股票分组，计算随后一年组合收益。
这些是研究用行业组合，不能直接等同于可交易证券或 ETF。实际落地还需要成分股、
权重、执行价格、成交量、借券和费用等数据。本包不包含这些字段。
在 notebook 中将它们作为资产列进行信号构造和组合回测，是研究方法练习。
由 (1+r).cumprod() 得到的是归一化财富指数，不是观察到的市场价格。
请明确执行时点与持仓滞后，成本参数只能做假设和敏感性分析。
数据网站会按月重建历史，历史数值可能被修订。当前下载快照不等于当时可知版本，
因此不能宣称该快照解决了全部 point-in-time 或幸存者偏差问题。

dirty 清洗练习说明（均为人为注入，不代表原始数据质量）
以 seed=20261005 从 clean 独立复制，打乱行顺序，并额外添加 60 条完全相同的重复行。
120 条行业名、60 条日期、60 条收益数字字符串被加上首尾空格。
60 个互不重复的真实收益值被移除：40 个写成 NA，20 个写成空字段。
各类受影响原始行彼此不重叠；dirty 共 120,780 行。
清理空白、解析类型、按 date + industry 去重后应有 120,720 行、60 个缺失收益。
这 60 个值无法仅凭 dirty 文件推回；不能默认缺失收益为零，也不能 forward-fill 收益率。
完成缺失报告后，请重新读取 clean 文件做分析和回测，避免把人为缺失影响混入策略。

版权与归属：原始下载文件署名 Eugene F. Fama and Kenneth R. French。
本包用于个人学习练习；不声称拥有原始数据版权，也未推断开放许可证。
